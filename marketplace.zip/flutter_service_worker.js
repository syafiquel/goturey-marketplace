'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"version.json": "de6b3ddc0fcabfbea52da8282ab7ece9",
"flutter.js": "83d881c1dbb6d6bcd6b42e274605b69c",
"index.html": "485bce217530a424cbae5e9991004a4b",
"/": "485bce217530a424cbae5e9991004a4b",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"marketplace.zip": "d54106be043ba8dbbde2736b4839de38",
"canvaskit/canvaskit.js.symbols": "bdcd3835edf8586b6d6edfce8749fb77",
"canvaskit/canvaskit.wasm": "7a3f4ae7d65fc1de6a6e7ddd3224bc93",
"canvaskit/chromium/canvaskit.js.symbols": "b61b5f4673c9698029fa0a746a9ad581",
"canvaskit/chromium/canvaskit.wasm": "f504de372e31c8031018a9ec0a9ef5f0",
"canvaskit/chromium/canvaskit.js": "8191e843020c832c9cf8852a4b909d4c",
"canvaskit/skwasm.wasm": "39dd80367a4e71582d234948adc521c0",
"canvaskit/skwasm.js": "ea559890a088fe28b4ddf70e17e60052",
"canvaskit/skwasm.js.symbols": "e72c79950c8a8483d826a7f0560573a1",
"canvaskit/canvaskit.js": "728b2d477d9b8c14593d4f9b82b484f3",
"main.dart.js": "bc828540a7fcc0bc9e3a97ec1e4ca079",
"assets/AssetManifest.json": "dec2fc42bcf9e31e39eff1025626236f",
"assets/packages/flutter_inappwebview/assets/t_rex_runner/t-rex.html": "16911fcc170c8af1c5457940bd0bf055",
"assets/packages/flutter_inappwebview/assets/t_rex_runner/t-rex.css": "5a8d0222407e388155d7d1395a75d5b9",
"assets/packages/flutter_inappwebview_web/assets/web/web_support.js": "509ae636cfdd93e49b5a6eaf0f06d79f",
"assets/packages/cooler_alerts/assets/flare/info_check.flr": "f6b81c2aa3ae36418c13bfd36d11ac04",
"assets/packages/cooler_alerts/assets/flare/error_check.flr": "d9f54791d0d79935d22206966707e4b3",
"assets/packages/cooler_alerts/assets/flare/success_check.flr": "9d163bcc6f6b58566e0abde7761a67a0",
"assets/packages/cooler_alerts/assets/flare/warning_check.flr": "ff4a110b8d905dedb4d4639a17399703",
"assets/packages/cooler_alerts/assets/flare/loading.flr": "b6987a8e6de74062b8c002539d2d043e",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/packages/fluttertoast/assets/toastify.css": "a85675050054f179444bc5ad70ffc635",
"assets/packages/fluttertoast/assets/toastify.js": "56e2c9cedd97f10e7e5f1cebd85d53e3",
"assets/packages/country_state_city_picker/lib/assets/country.json": "11b8187fd184a2d648d6b5be8c5e9908",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/fonts/MaterialIcons-Regular.otf": "f77bb16d18d7a976f3d60f1e69f28593",
"assets/assets/images/google.png": "f6b7d0aa1e3cdd9ffc93acb194cb1153",
"assets/assets/images/sign_up.png": "f96388dc83ffbee700b402f415de884a",
"assets/assets/images/empty.png": "98f71224eabce3d7cd99994e97e14c04",
"assets/assets/images/shoe_logo.png": "188f7f0cfd3bfc16b362b09537df952a",
"assets/assets/images/warning.png": "97183737ecc03edaa8a36a98f9b15494",
"assets/assets/images/email.png": "17c50ab59f96a3117b3ed3f6468d4077",
"assets/assets/images/add.png": "4b8ebc68ee745cbecb7d64a29e0400ea",
"assets/assets/images/facebook.png": "7907c081a87bc6707f519c9427e4a02c",
"assets/assets/images/log.png": "2f1688f61121417d54c4ad5ec1570191",
"assets/assets/images/sp2.png": "a79e237f56fd33d0ad352d7eea6339ab",
"assets/assets/images/default.png": "7944b394dd01fd090e883a9838e21601",
"assets/assets/images/forgot_password.png": "2a3b476963f0821ed22ab2a5352ce0ba",
"assets/assets/images/sp1.png": "effcda7ff50bb619cbe730732529d711",
"assets/assets/images/placeholder-img.jpg": "9e3f64ea883c30a596a31cc5f4d98510",
"assets/assets/images/all.jpg": "be3ff5cedaf45aef6520abace5ff110e",
"assets/assets/images/love.gif": "8e2768589e45d808d10cbe455efbb9ef",
"assets/assets/images/check.png": "326f98017d1db348aa9a53464cfbedb2",
"assets/assets/images/payment.png": "6da3fdc5909fb7bcce4ee2cf21858a83",
"assets/assets/images/shoe_logo_transparent.png": "659bfe4d760dbb3231bd81f9478a8194",
"assets/assets/images/ops.png": "a48af09a85d6a3fdc19a3206381da1b1",
"assets/assets/images/avatar.jpg": "19c7f0bbf81c7001222a0bdc995cd710",
"assets/assets/images/empty-img.jpg": "33f2c94149baa62dd02d6fd51016e6bb",
"assets/assets/images/sp3.png": "2b30c0ad9b27a4b6a311ae2692d5e9f4",
"assets/assets/icons/search.svg": "0eeb1ef28e8ca82d9c279a569b63b7c5",
"assets/assets/icons/shop.svg": "ce01a2186d66c9f61f3d9e6c6e31e24f",
"assets/assets/icons/explore.svg": "f8ba26d9347a3f09da2769efc0f87a5f",
"assets/assets/icons/cart.svg": "40fa47e7f04acd012c0b3e7ff290de80",
"assets/assets/icons/favorite.svg": "34bfb6b8c1fd6833e4d6b1835ef38ad2",
"assets/assets/icons/account.svg": "be61da1d6af873d51c01701e68540159",
"assets/AssetManifest.bin": "c30f3ca05e9d5004dcec6807ee74722f",
"assets/AssetManifest.bin.json": "31740bd67d5ebe94fbc23f329890a8d5",
"assets/NOTICES": "21979aa52da8a5e5715fa0a2d26d4352",
"flutter_bootstrap.js": "0d7bd5d06ab7ac551378ce8efc2c3a7d",
"manifest.json": "1278558e9d85297174d47caf40408dd5",
"favicon.png": "5dcef449791fa27946b3d35ad8803796"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
